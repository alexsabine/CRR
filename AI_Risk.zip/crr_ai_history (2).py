"""
CRR Analysis of AI History: Coherence-Rupture-Regeneration Dynamics
in Artificial Intelligence Development (1943-2026+)

Framework: Alexander Sabine's CRR
- C(x,t) = ∫L(x,τ)dτ  — coherence accumulation
- δ(now)               — rupture as scale-invariant choice-moments  
- R = ∫φ(x,τ)exp(C/Ω)Θ(...)dτ — regeneration with exponential memory weighting

Applied to: The temporal dynamics of AI research, breakthroughs, and paradigm shifts
"""

import numpy as np
from scipy.optimize import curve_fit
from scipy.signal import find_peaks
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.gridspec import GridSpec
import json
import warnings
warnings.filterwarnings('ignore')

# =============================================================================
# 1. AI HISTORY DATABASE — Events with coherence contributions
# =============================================================================

ai_events = [
    # (year, name, type, magnitude, domain)
    # type: 'C' = coherence building, 'δ' = rupture, 'R' = regeneration marker
    # magnitude: relative importance (1-10 scale)
    
    # Pre-AI Foundations
    (1943, "McCulloch-Pitts Neural Model", 'C', 3, "theory"),
    (1948, "Wiener's Cybernetics", 'C', 3, "theory"),
    (1950, "Turing's 'Computing Machinery & Intelligence'", 'C', 5, "theory"),
    (1951, "Marvin Minsky's SNARC (first neural net machine)", 'C', 3, "hardware"),
    (1952, "Samuel's Checkers Program", 'C', 2, "applications"),
    
    # First AI Spring (Dartmouth era)
    (1956, "Dartmouth Conference — AI founded as field", 'C', 7, "institutional"),
    (1957, "Rosenblatt's Perceptron", 'C', 5, "theory"),
    (1958, "McCarthy's LISP", 'C', 4, "tools"),
    (1959, "General Problem Solver (Newell & Simon)", 'C', 4, "applications"),
    (1961, "Unimate: first industrial robot", 'C', 3, "robotics"),
    (1964, "ELIZA (Weizenbaum)", 'C', 4, "NLP"),
    (1966, "ALPAC Report — MT funding cut", 'δ', 4, "institutional"),
    (1965, "Fuzzy Logic (Zadeh)", 'C', 3, "theory"),
    
    # FIRST AI WINTER — MAJOR RUPTURE
    (1969, "Minsky & Papert's 'Perceptrons' critique", 'δ', 8, "theory"),
    (1973, "Lighthill Report (UK)", 'δ', 7, "institutional"),
    (1974, "DARPA funding cuts", 'δ', 6, "institutional"),
    
    # Quiet Regeneration / Second Spring
    (1976, "Backpropagation concept (Werbos)", 'R', 4, "theory"),
    (1980, "Expert Systems emerge (XCON/R1)", 'R', 6, "applications"),
    (1981, "Japan's Fifth Generation Project", 'C', 5, "institutional"),
    (1982, "Hopfield Networks", 'C', 5, "theory"),
    (1984, "Cyc Project begins", 'C', 3, "knowledge"),
    (1985, "Boltzmann Machines (Hinton & Sejnowski)", 'C', 4, "theory"),
    (1986, "Backprop revival (Rumelhart, Hinton, Williams)", 'C', 7, "theory"),
    (1987, "Expert systems market peak (~$1B)", 'C', 5, "commercial"),
    
    # SECOND AI WINTER — MAJOR RUPTURE
    (1988, "Expert systems collapse begins", 'δ', 7, "commercial"),
    (1989, "Fifth Generation Project fails", 'δ', 5, "institutional"),
    (1990, "LISP machine market crashes", 'δ', 5, "commercial"),
    (1993, "AI winter nadir — funding at lowest", 'δ', 6, "institutional"),
    
    # Statistical ML Regeneration
    (1995, "Support Vector Machines (Vapnik)", 'R', 5, "theory"),
    (1997, "Deep Blue beats Kasparov", 'R', 6, "applications"),
    (1997, "LSTM networks (Hochreiter & Schmidhuber)", 'C', 6, "theory"),
    (1998, "LeNet-5 / Convolutional nets (LeCun)", 'C', 5, "theory"),
    (2000, "Bayesian methods flourish", 'C', 4, "theory"),
    (2004, "DARPA Grand Challenge", 'C', 4, "robotics"),
    (2006, "Hinton's Deep Belief Networks paper", 'C', 6, "theory"),
    (2007, "CUDA enables GPU computing", 'C', 5, "hardware"),
    (2009, "ImageNet dataset created", 'C', 5, "data"),
    (2010, "Siri (acquired by Apple)", 'C', 3, "applications"),
    (2011, "Watson wins Jeopardy!", 'C', 4, "applications"),
    
    # DEEP LEARNING RUPTURE — PARADIGM SHIFT
    (2012, "AlexNet wins ImageNet (Krizhevsky et al.)", 'δ', 9, "theory"),
    
    # Deep Learning Regeneration & Acceleration
    (2013, "Word2Vec (Mikolov)", 'R', 5, "NLP"),
    (2014, "GANs (Goodfellow)", 'C', 7, "theory"),
    (2014, "Seq2Seq / Attention foundations", 'C', 6, "theory"),
    (2015, "ResNets (He et al.)", 'C', 5, "theory"),
    (2015, "AlphaGo development", 'C', 6, "applications"),
    (2016, "AlphaGo beats Lee Sedol", 'C', 7, "applications"),
    
    # TRANSFORMER RUPTURE
    (2017, "Attention Is All You Need (Vaswani et al.)", 'δ', 9, "theory"),
    
    # LLM Regeneration & Scaling
    (2018, "BERT (Google)", 'R', 6, "NLP"),
    (2018, "GPT-1 (OpenAI)", 'C', 5, "NLP"),
    (2019, "GPT-2 ('too dangerous to release')", 'C', 6, "NLP"),
    (2020, "GPT-3 — scaling laws validated", 'C', 8, "NLP"),
    (2020, "AlphaFold 2 — protein folding solved", 'C', 7, "science"),
    (2021, "DALL-E, Codex", 'C', 6, "multimodal"),
    (2021, "Chinchilla scaling laws", 'C', 5, "theory"),
    
    # CHATGPT RUPTURE — SOCIETAL PARADIGM SHIFT
    (2022, "ChatGPT launch — AI goes mainstream", 'δ', 10, "societal"),
    (2022, "Stable Diffusion — open source image gen", 'C', 6, "multimodal"),
    
    # Current Regeneration — Acceleration Phase
    (2023, "GPT-4 — multimodal frontier", 'R', 8, "NLP"),
    (2023, "Claude 2, Llama 2, Gemini — pluralization", 'C', 7, "institutional"),
    (2023, "AI safety discourse intensifies", 'C', 5, "societal"),
    (2024, "Claude 3.5, GPT-4o, Gemini Ultra — rapid iteration", 'C', 8, "NLP"),
    (2024, "AI agents emerge, coding assistants mature", 'C', 7, "applications"),
    (2024, "Scaling debate: are we hitting walls?", 'C', 5, "theory"),
    (2025, "Claude 4.5, reasoning models, AI-for-science", 'C', 8, "NLP"),
    (2025, "EU AI Act enforcement, governance frameworks", 'C', 6, "institutional"),
    (2025, "Agentic AI systems proliferate", 'C', 7, "applications"),
]

# =============================================================================
# 2. CRR MATHEMATICAL ENGINE
# =============================================================================

class CRRAnalysis:
    """CRR temporal analysis engine for AI history."""
    
    def __init__(self, events):
        self.events = sorted(events, key=lambda x: x[0])
        self.years = np.array([e[0] for e in events])
        self.magnitudes = np.array([e[3] for e in events])
        self.types = [e[2] for e in events]
        
        # Time axis (continuous)
        self.t = np.linspace(1943, 2035, 2000)
        
        # Identify rupture points
        self.ruptures = [(e[0], e[1], e[3]) for e in events if e[2] == 'δ']
        self.rupture_years = np.array([r[0] for r in self.ruptures])
        self.rupture_magnitudes = np.array([r[2] for r in self.ruptures])
        
        # Major cycle boundaries (the big ruptures)
        self.major_ruptures = [
            (1969, "First AI Winter", 8),
            (1988, "Second AI Winter", 7),
            (2012, "Deep Learning Revolution", 9),
            (2017, "Transformer Paradigm", 9),
            (2022, "ChatGPT Societal Shift", 10),
        ]
        
    def compute_coherence(self):
        """
        C(t) = ∫L(x,τ)dτ — coherence accumulation over time.
        L(x,τ) represents the rate of knowledge/capability accumulation.
        Ruptures cause partial coherence loss; regeneration rebuilds.
        """
        C = np.zeros_like(self.t)
        
        for i, t_val in enumerate(self.t):
            # Sum contributions from all events up to time t
            for event in self.events:
                year, name, etype, mag, domain = event
                if year <= t_val:
                    # Coherence events add, ruptures subtract
                    if etype == 'C':
                        # Coherence decays slowly over time (knowledge persists but relevance fades)
                        decay = np.exp(-(t_val - year) / 30)  # 30-year relevance half-life
                        C[i] += mag * (1 - decay * 0.3)  # Retains 70% permanently
                    elif etype == 'δ':
                        # Ruptures create temporary coherence loss
                        time_since = t_val - year
                        if time_since < 8:  # Winter lasts ~8 years
                            C[i] -= mag * np.exp(-time_since / 3)
                    elif etype == 'R':
                        # Regeneration weighted by prior coherence
                        C[i] += mag * 0.8
        
        self.C = C
        return C
    
    def compute_rupture_field(self):
        """
        δ(now) — rupture intensity field.
        Models the Dirac delta as narrow Gaussians for visualization.
        """
        delta = np.zeros_like(self.t)
        
        for year, name, mag in self.ruptures:
            # Each rupture as a narrow Gaussian
            sigma = 0.5  # ~6 months width
            delta += mag * np.exp(-(self.t - year)**2 / (2 * sigma**2))
        
        self.delta = delta
        return delta
    
    def compute_regeneration(self):
        """
        R = ∫φ(x,τ)exp(C(x,τ)/Ω)Θ(...)dτ
        
        The key insight: exp(C/Ω) determines WHICH prior knowledge 
        gets amplified during regeneration.
        
        For AI: after each winter, specific subfields were amplified
        (neural nets after winter 1, statistical ML after winter 2,
        deep learning after the AlexNet rupture).
        """
        R = np.zeros_like(self.t)
        
        # Compute Ω for each major cycle
        self.omegas = self.estimate_omega()
        
        # For each time point after a rupture, compute regeneration
        for idx, (rup_year, rup_name, rup_mag) in enumerate(self.major_ruptures):
            omega = self.omegas[idx]
            
            for i, t_val in enumerate(self.t):
                if t_val > rup_year:
                    time_since = t_val - rup_year
                    
                    # Coherence at rupture point
                    rup_idx = np.argmin(np.abs(self.t - rup_year))
                    C_at_rupture = self.C[rup_idx] if hasattr(self, 'C') else 50
                    
                    # exp(C/Ω) — memory amplification
                    # Higher C/Ω = more selective memory (peaked)
                    # Lower C/Ω = broader memory access
                    memory_weight = np.exp(min(C_at_rupture / (omega * 50), 10))
                    
                    # Regeneration builds up then plateaus
                    phi = rup_mag * (1 - np.exp(-time_since / 5))
                    
                    # Heaviside: only after rupture
                    R[i] += phi * np.log1p(memory_weight) * 0.3
        
        self.R = R
        return R
    
    def estimate_omega(self):
        """
        Estimate Ω for each major CRR cycle.
        
        Ω = 1/φ where φ = phase to rupture
        Lower Ω → more rigid, frequent micro-ruptures
        Higher Ω → more flexible, transformative change possible
        
        For AI: Ω should be DECREASING as cycles shorten
        (the field becomes more rigid/fast-cycling)
        """
        cycle_boundaries = [1943] + [r[0] for r in self.major_ruptures] + [2026]
        omegas = []
        
        for i in range(len(self.major_ruptures)):
            start = cycle_boundaries[i]
            end = self.major_ruptures[i][0]
            duration = end - start
            
            # Count events in this cycle
            cycle_events = [e for e in self.events if start <= e[0] < end]
            n_events = len(cycle_events)
            
            # Ω proportional to cycle duration / event density
            # Shorter cycles with more events → lower Ω → more rigid
            event_density = n_events / max(duration, 1)
            omega = 1 / (np.pi * event_density) if event_density > 0 else 1/np.pi
            
            omegas.append(omega)
        
        self.omegas = omegas
        return omegas
    
    def compute_crr_composite(self):
        """Compute the full CRR composite signal."""
        self.compute_coherence()
        self.compute_rupture_field()
        self.compute_regeneration()
        
        # Composite: C + R - impact of δ
        self.composite = self.C + self.R
        
        # Rate of change (velocity of AI development)
        dt = self.t[1] - self.t[0]
        self.velocity = np.gradient(self.composite, dt)
        self.acceleration = np.gradient(self.velocity, dt)
        
        return self.composite
    
    def predict_future(self):
        """
        Use CRR dynamics to project forward.
        
        Key predictions from CRR:
        1. Decreasing Ω → approaching critical transition
        2. exp(C/Ω) increasingly peaked → system becoming rigid
        3. Next rupture magnitude should exceed previous
        4. Time-to-rupture decreasing exponentially
        """
        predictions = {}
        
        # 1. Cycle duration analysis
        cycle_durations = []
        for i in range(1, len(self.major_ruptures)):
            dur = self.major_ruptures[i][0] - self.major_ruptures[i-1][0]
            cycle_durations.append(dur)
        
        predictions['cycle_durations'] = cycle_durations
        predictions['cycle_labels'] = [f"{self.major_ruptures[i][1]}→{self.major_ruptures[i+1][1]}" 
                                        for i in range(len(self.major_ruptures)-1)]
        
        # 2. Fit exponential decay to cycle durations
        x = np.arange(len(cycle_durations))
        try:
            def exp_decay(x, a, b):
                return a * np.exp(-b * x)
            popt, _ = curve_fit(exp_decay, x, cycle_durations, p0=[20, 0.3])
            
            # Predict next cycle duration
            next_duration = exp_decay(len(cycle_durations), *popt)
            predictions['next_cycle_duration'] = next_duration
            predictions['next_rupture_year'] = 2022 + next_duration
            predictions['decay_params'] = popt
        except:
            predictions['next_cycle_duration'] = 3.0
            predictions['next_rupture_year'] = 2025
        
        # 3. Ω trajectory
        predictions['omega_values'] = self.omegas
        predictions['omega_trend'] = "decreasing — approaching critical rigidity"
        
        # 4. Rupture magnitude escalation
        mags = [r[2] for r in self.major_ruptures]
        predictions['rupture_magnitudes'] = mags
        
        # Linear trend in magnitude
        mag_slope = np.polyfit(range(len(mags)), mags, 1)
        next_mag = np.polyval(mag_slope, len(mags))
        predictions['next_rupture_magnitude'] = min(next_mag, 10)
        
        # 5. exp(C/Ω) ratio — memory selectivity
        C_recent = self.C[np.argmin(np.abs(self.t - 2025))]
        omega_recent = self.omegas[-1]
        predictions['current_C_over_Omega'] = C_recent / (omega_recent * 50)
        predictions['memory_selectivity'] = "HIGHLY PEAKED — system increasingly rigid"
        
        # 6. Threat assessment based on CRR dynamics
        predictions['threat_analysis'] = self._threat_analysis()
        
        self.predictions = predictions
        return predictions
    
    def _threat_analysis(self):
        """CRR-derived threat analysis for AI."""
        threats = [
            {
                'name': 'Coherence Lock-in (Low Ω Rigidity)',
                'description': 'As Ω decreases, AI development becomes locked into current paradigms. '
                              'exp(C/Ω) becomes highly peaked, meaning only recent high-coherence '
                              'approaches (scaling, transformers) are accessible. Alternative approaches '
                              '(symbolic, neuroscience-inspired, embodied) become invisible to the field.',
                'severity': 8,
                'timeframe': 'Now — 2027',
                'crr_mechanism': 'Low Ω → peaked exp(C/Ω) → paradigm lock-in'
            },
            {
                'name': 'Catastrophic Rupture from Over-Coherence',
                'description': 'Each AI winter followed a period of excessive coherence (hype). '
                              'Current coherence levels are historically unprecedented. CRR predicts '
                              'that systems with very high C and decreasing Ω experience larger ruptures. '
                              'A major AI failure/incident could trigger societal backlash exceeding '
                              'previous winters.',
                'severity': 9,
                'timeframe': '2025 — 2030',
                'crr_mechanism': 'High C + Low Ω → catastrophic δ magnitude'
            },
            {
                'name': 'Regeneration Asymmetry (Winner-Take-All)',
                'description': 'In regeneration, exp(C/Ω) amplifies highest-coherence memories. '
                              'For AI: after any disruption, the most well-resourced approaches '
                              '(big tech, scaling) regenerate fastest while alternatives die. '
                              'This creates dangerous monoculture.',
                'severity': 7,
                'timeframe': '2025 — 2035',
                'crr_mechanism': 'Peaked exp(C/Ω) → selective regeneration → monoculture'
            },
            {
                'name': 'Cycle Compression Singularity',
                'description': 'AI development cycles are compressing exponentially: '
                              '19→24→5→5→5 years. CRR predicts this approaches a limit where '
                              'C-δ-R cycles become continuous — permanent revolution with no '
                              'stable coherence phase. This is structurally analogous to a phase '
                              'transition at the Z₂/SO(2) boundary.',
                'severity': 9,
                'timeframe': '2027 — 2035',
                'crr_mechanism': 'Ω → 0 implies continuous δ: permanent disruption'
            },
            {
                'name': 'Alignment as Ω Modulation Failure',
                'description': 'AI alignment is fundamentally an Ω problem: can we maintain '
                              'appropriate boundaries (Ω) between AI capability (C) and human '
                              'values? CRR shows that Ω must be actively maintained — it cannot '
                              'be set once. As C grows exponentially, Ω modulation becomes '
                              'increasingly difficult.',
                'severity': 10,
                'timeframe': '2025 — 2040+',
                'crr_mechanism': 'C growing faster than Ω can be modulated → loss of control'
            },
            {
                'name': 'Deep Time Prior Erasure',
                'description': 'CRR\'s exp(C/Ω) mechanism shows that with low Ω, only recent '
                              'high-coherence states are accessible. For AI development, this means '
                              'foundational insights (cybernetics, cognitive science, philosophy of mind) '
                              'become inaccessible — the field loses touch with its own deep priors. '
                              'This mirrors how contemplative traditions warn about losing connection '
                              'to wisdom traditions.',
                'severity': 7,
                'timeframe': 'Now — ongoing',
                'crr_mechanism': 'Low Ω → peaked memory → loss of deep time priors'
            }
        ]
        return threats
    
    def compute_cycle_statistics(self):
        """Compute detailed statistics for each CRR cycle."""
        cycles = []
        boundaries = [1943] + [r[0] for r in self.major_ruptures] + [2026]
        
        for i in range(len(boundaries) - 1):
            start = boundaries[i]
            end = boundaries[i+1]
            
            cycle_events = [e for e in self.events if start <= e[0] < end]
            c_events = [e for e in cycle_events if e[2] == 'C']
            r_events = [e for e in cycle_events if e[2] == 'R']
            d_events = [e for e in cycle_events if e[2] == 'δ']
            
            # Coherence at start and end of cycle
            idx_start = np.argmin(np.abs(self.t - start))
            idx_end = np.argmin(np.abs(self.t - end))
            
            cycle_info = {
                'period': f"{start}—{end}",
                'duration': end - start,
                'n_events': len(cycle_events),
                'n_coherence': len(c_events),
                'n_rupture': len(d_events),
                'n_regeneration': len(r_events),
                'total_coherence_added': sum(e[3] for e in c_events),
                'total_rupture_impact': sum(e[3] for e in d_events),
                'C_start': float(self.C[idx_start]),
                'C_end': float(self.C[idx_end]),
                'omega': self.omegas[i] if i < len(self.omegas) else None,
                'domains': list(set(e[4] for e in cycle_events)),
                'label': self.major_ruptures[i][1] if i < len(self.major_ruptures) else "Current Phase"
            }
            cycles.append(cycle_info)
        
        self.cycles = cycles
        return cycles


# =============================================================================
# 3. VISUALIZATION ENGINE
# =============================================================================

def create_visualizations(analysis):
    """Generate comprehensive CRR visualization plots."""
    
    # Color palette
    colors = {
        'coherence': '#2ecc71',
        'rupture': '#e74c3c',
        'regeneration': '#3498db',
        'composite': '#f39c12',
        'prediction': '#9b59b6',
        'background': '#1a1a2e',
        'text': '#e0e0e0',
        'grid': '#333355',
        'accent': '#00d4ff',
    }
    
    fig = plt.figure(figsize=(28, 36), facecolor=colors['background'])
    gs = GridSpec(6, 2, figure=fig, hspace=0.35, wspace=0.25,
                  left=0.06, right=0.96, top=0.95, bottom=0.03)
    
    def style_ax(ax, title):
        ax.set_facecolor(colors['background'])
        ax.tick_params(colors=colors['text'], labelsize=9)
        ax.set_title(title, color=colors['accent'], fontsize=13, fontweight='bold', pad=10)
        for spine in ax.spines.values():
            spine.set_color(colors['grid'])
        ax.grid(True, alpha=0.15, color=colors['grid'])
    
    # --- PLOT 1: Coherence C(t) with events ---
    ax1 = fig.add_subplot(gs[0, :])
    style_ax(ax1, 'COHERENCE ACCUMULATION  C(t) = ∫L(x,τ)dτ')
    
    ax1.fill_between(analysis.t, 0, analysis.C, alpha=0.3, color=colors['coherence'])
    ax1.plot(analysis.t, analysis.C, color=colors['coherence'], linewidth=2, label='C(t)')
    
    # Mark major events
    for event in analysis.events:
        year, name, etype, mag, domain = event
        if mag >= 7:
            color = colors['coherence'] if etype == 'C' else colors['rupture'] if etype == 'δ' else colors['regeneration']
            idx = np.argmin(np.abs(analysis.t - year))
            ax1.scatter([year], [analysis.C[idx]], color=color, s=mag*20, zorder=5, edgecolors='white', linewidth=0.5)
            if mag >= 8:
                ax1.annotate(f'{name[:35]}', (year, analysis.C[idx]), 
                           xytext=(5, 10), textcoords='offset points',
                           fontsize=7, color=colors['text'], alpha=0.8,
                           arrowprops=dict(arrowstyle='->', color=colors['text'], alpha=0.3))
    
    ax1.set_xlabel('Year', color=colors['text'])
    ax1.set_ylabel('Coherence C(t)', color=colors['text'])
    ax1.legend(loc='upper left', facecolor=colors['background'], edgecolor=colors['grid'], labelcolor=colors['text'])
    
    # --- PLOT 2: Rupture Field δ(t) ---
    ax2 = fig.add_subplot(gs[1, 0])
    style_ax(ax2, 'RUPTURE FIELD  δ(now)')
    
    ax2.fill_between(analysis.t, 0, analysis.delta, alpha=0.4, color=colors['rupture'])
    ax2.plot(analysis.t, analysis.delta, color=colors['rupture'], linewidth=1.5)
    
    for year, name, mag in analysis.major_ruptures:
        idx = np.argmin(np.abs(analysis.t - year))
        ax2.annotate(f'{name}\n({year})', (year, analysis.delta[idx]),
                    xytext=(0, 15), textcoords='offset points',
                    fontsize=7, color=colors['text'], ha='center',
                    fontweight='bold',
                    arrowprops=dict(arrowstyle='->', color=colors['rupture']))
    
    ax2.set_xlabel('Year', color=colors['text'])
    ax2.set_ylabel('Rupture Intensity', color=colors['text'])
    
    # --- PLOT 3: Regeneration R(t) ---
    ax3 = fig.add_subplot(gs[1, 1])
    style_ax(ax3, 'REGENERATION  R = ∫φ·exp(C/Ω)·Θ dτ')
    
    ax3.fill_between(analysis.t, 0, analysis.R, alpha=0.4, color=colors['regeneration'])
    ax3.plot(analysis.t, analysis.R, color=colors['regeneration'], linewidth=1.5)
    ax3.set_xlabel('Year', color=colors['text'])
    ax3.set_ylabel('Regeneration R(t)', color=colors['text'])
    
    # --- PLOT 4: Composite CRR Signal ---
    ax4 = fig.add_subplot(gs[2, :])
    style_ax(ax4, 'COMPOSITE CRR SIGNAL — AI Development Trajectory')
    
    ax4.plot(analysis.t, analysis.composite, color=colors['composite'], linewidth=2.5, label='CRR Composite')
    ax4.fill_between(analysis.t, 0, analysis.composite, alpha=0.2, color=colors['composite'])
    
    # Shade major cycles
    cycle_colors = ['#1a3a4a', '#1a2a3a', '#2a1a3a', '#1a3a2a', '#3a2a1a', '#2a3a1a']
    boundaries = [1943] + [r[0] for r in analysis.major_ruptures] + [2035]
    for i in range(len(boundaries)-1):
        ax4.axvspan(boundaries[i], boundaries[i+1], alpha=0.15, 
                    color=cycle_colors[i % len(cycle_colors)])
    
    # Mark ruptures
    for year, name, mag in analysis.major_ruptures:
        ax4.axvline(x=year, color=colors['rupture'], alpha=0.7, linestyle='--', linewidth=1)
        idx = np.argmin(np.abs(analysis.t - year))
        ax4.annotate(f'δ: {name}', (year, analysis.composite[idx]),
                    xytext=(5, -20), textcoords='offset points',
                    fontsize=7, color=colors['rupture'], rotation=45)
    
    # Future prediction zone
    ax4.axvspan(2025, 2035, alpha=0.1, color=colors['prediction'], label='Prediction Zone')
    
    ax4.set_xlabel('Year', color=colors['text'])
    ax4.set_ylabel('CRR Composite', color=colors['text'])
    ax4.legend(loc='upper left', facecolor=colors['background'], edgecolor=colors['grid'], labelcolor=colors['text'])
    
    # --- PLOT 5: Ω Trajectory ---
    ax5 = fig.add_subplot(gs[3, 0])
    style_ax(ax5, 'Ω TRAJECTORY — Boundary Permeability')
    
    omega_years = [r[0] for r in analysis.major_ruptures]
    omegas = analysis.omegas[:len(omega_years)]
    
    ax5.plot(omega_years, omegas, 'o-', color=colors['accent'], linewidth=2, markersize=10)
    ax5.fill_between(omega_years, 0, omegas, alpha=0.2, color=colors['accent'])
    
    for i, (y, o) in enumerate(zip(omega_years, omegas)):
        ax5.annotate(f'Ω={o:.3f}\n{analysis.major_ruptures[i][1][:15]}', 
                    (y, o), xytext=(0, 12), textcoords='offset points',
                    fontsize=7, color=colors['text'], ha='center')
    
    # Add critical threshold
    ax5.axhline(y=0.05, color=colors['rupture'], alpha=0.5, linestyle=':', label='Critical Threshold')
    ax5.set_xlabel('Year', color=colors['text'])
    ax5.set_ylabel('Ω', color=colors['text'])
    ax5.legend(facecolor=colors['background'], edgecolor=colors['grid'], labelcolor=colors['text'])
    
    # --- PLOT 6: Cycle Duration Compression ---
    ax6 = fig.add_subplot(gs[3, 1])
    style_ax(ax6, 'CYCLE COMPRESSION — Time Between Ruptures')
    
    durations = analysis.predictions['cycle_durations']
    labels = [f"Cycle {i+1}" for i in range(len(durations))]
    
    bars = ax6.bar(labels, durations, color=colors['prediction'], alpha=0.7, edgecolor=colors['accent'])
    
    # Add trend line
    x_fit = np.arange(len(durations))
    if 'decay_params' in analysis.predictions:
        a, b = analysis.predictions['decay_params']
        x_ext = np.linspace(0, len(durations)+1, 50)
        y_fit = a * np.exp(-b * x_ext)
        ax6.plot(x_ext, y_fit, '--', color=colors['rupture'], linewidth=2, label='Exponential Decay')
    
    for i, (bar, dur) in enumerate(zip(bars, durations)):
        ax6.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.3,
                f'{dur:.0f}yr', ha='center', va='bottom', color=colors['text'], fontsize=9)
    
    # Predicted next
    if 'next_cycle_duration' in analysis.predictions:
        next_dur = analysis.predictions['next_cycle_duration']
        ax6.bar([f"NEXT?"], [next_dur], color=colors['rupture'], alpha=0.5, edgecolor=colors['accent'])
        ax6.text(len(durations), next_dur + 0.3, f'{next_dur:.1f}yr?',
                ha='center', va='bottom', color=colors['rupture'], fontsize=9, fontweight='bold')
    
    ax6.set_ylabel('Years', color=colors['text'])
    ax6.legend(facecolor=colors['background'], edgecolor=colors['grid'], labelcolor=colors['text'])
    
    # --- PLOT 7: Velocity & Acceleration ---
    ax7 = fig.add_subplot(gs[4, 0])
    style_ax(ax7, 'RATE OF CHANGE — dC/dt (AI Development Velocity)')
    
    ax7.plot(analysis.t, analysis.velocity, color=colors['coherence'], linewidth=1.5, label='Velocity dC/dt')
    ax7.fill_between(analysis.t, 0, analysis.velocity, 
                     where=analysis.velocity > 0, alpha=0.3, color=colors['coherence'])
    ax7.fill_between(analysis.t, 0, analysis.velocity,
                     where=analysis.velocity < 0, alpha=0.3, color=colors['rupture'])
    ax7.axhline(y=0, color=colors['text'], alpha=0.3, linewidth=0.5)
    ax7.set_xlabel('Year', color=colors['text'])
    ax7.set_ylabel('dC/dt', color=colors['text'])
    ax7.legend(facecolor=colors['background'], edgecolor=colors['grid'], labelcolor=colors['text'])
    
    # --- PLOT 8: exp(C/Ω) Memory Selectivity ---
    ax8 = fig.add_subplot(gs[4, 1])
    style_ax(ax8, 'exp(C/Ω) — MEMORY SELECTIVITY (Paradigm Rigidity)')
    
    # Compute exp(C/Ω) at each major rupture
    exp_ratios = []
    for i, (year, name, mag) in enumerate(analysis.major_ruptures):
        idx = np.argmin(np.abs(analysis.t - year))
        C_val = analysis.C[idx]
        omega = analysis.omegas[i]
        ratio = np.exp(min(C_val / (omega * 50), 10))
        exp_ratios.append(ratio)
    
    rupture_labels = [f"{r[1][:12]}\n({r[0]})" for r in analysis.major_ruptures]
    bars = ax8.bar(rupture_labels, exp_ratios, color=colors['accent'], alpha=0.7, edgecolor='white')
    
    ax8.set_ylabel('exp(C/Ω)', color=colors['text'])
    ax8.tick_params(axis='x', labelsize=7, rotation=30)
    ax8.set_yscale('log')
    
    # --- PLOT 9: Threat Assessment ---
    ax9 = fig.add_subplot(gs[5, :])
    style_ax(ax9, 'CRR THREAT ANALYSIS — AI Risk Predictions from Temporal Dynamics')
    ax9.axis('off')
    
    threats = analysis.predictions['threat_analysis']
    y_pos = 0.95
    
    for threat in threats:
        severity = threat['severity']
        color = '#ff4444' if severity >= 9 else '#ff8844' if severity >= 7 else '#ffcc44'
        
        # Severity bar
        bar_width = severity / 10
        bar = FancyBboxPatch((0.02, y_pos - 0.03), bar_width * 0.15, 0.025,
                            boxstyle="round,pad=0.005", 
                            facecolor=color, alpha=0.6)
        ax9.add_patch(bar)
        
        ax9.text(0.18, y_pos, f"{threat['name']} [{threat['severity']}/10]",
                fontsize=9, fontweight='bold', color=color, 
                transform=ax9.transAxes, verticalalignment='center')
        
        ax9.text(0.18, y_pos - 0.04, f"{threat['timeframe']} | {threat['crr_mechanism']}",
                fontsize=7, color=colors['text'], alpha=0.7,
                transform=ax9.transAxes, verticalalignment='center')
        
        # Wrap description
        desc = threat['description']
        wrapped = [desc[i:i+110] for i in range(0, len(desc), 110)]
        for j, line in enumerate(wrapped[:2]):
            ax9.text(0.18, y_pos - 0.065 - j*0.03, line,
                    fontsize=7, color=colors['text'], alpha=0.5,
                    transform=ax9.transAxes, verticalalignment='center')
        
        y_pos -= 0.16
    
    # Title
    fig.suptitle('CRR ANALYSIS OF AI HISTORY\nCoherence-Rupture-Regeneration Dynamics in Artificial Intelligence (1943—2035+)',
                 color=colors['accent'], fontsize=18, fontweight='bold', y=0.98)
    
    fig.text(0.5, 0.96, 'Framework: Alexander Sabine | C(x,t)=∫L(x,τ)dτ  ·  δ(now)  ·  R=∫φ·exp(C/Ω)·Θ dτ',
            color=colors['text'], fontsize=10, ha='center', alpha=0.6)
    
    return fig


# =============================================================================
# 4. RUN ANALYSIS & GENERATE OUTPUTS
# =============================================================================

def main():
    print("=" * 70)
    print("CRR ANALYSIS OF AI HISTORY")
    print("Coherence-Rupture-Regeneration Dynamics (1943-2035+)")
    print("=" * 70)
    
    # Initialize
    analysis = CRRAnalysis(ai_events)
    
    # Compute CRR
    print("\n▸ Computing coherence C(t)...")
    analysis.compute_crr_composite()
    
    print("▸ Computing cycle statistics...")
    cycles = analysis.compute_cycle_statistics()
    
    print("▸ Generating predictions...")
    predictions = analysis.predict_future()
    
    # Print cycle analysis
    print("\n" + "=" * 70)
    print("CYCLE ANALYSIS")
    print("=" * 70)
    
    for i, cycle in enumerate(cycles):
        print(f"\n{'─' * 50}")
        print(f"CYCLE {i+1}: {cycle['label']}")
        print(f"  Period:     {cycle['period']}")
        print(f"  Duration:   {cycle['duration']} years")
        print(f"  Events:     {cycle['n_events']} total ({cycle['n_coherence']}C, {cycle['n_rupture']}δ, {cycle['n_regeneration']}R)")
        print(f"  Coherence:  {cycle['C_start']:.1f} → {cycle['C_end']:.1f}")
        if cycle['omega'] is not None:
            print(f"  Ω:          {cycle['omega']:.4f}")
        print(f"  Domains:    {', '.join(cycle['domains'])}")
    
    # Print predictions
    print("\n" + "=" * 70)
    print("CRR PREDICTIONS")
    print("=" * 70)
    
    print(f"\nCycle durations: {predictions['cycle_durations']} years")
    print(f"Trend: EXPONENTIAL COMPRESSION")
    if 'next_cycle_duration' in predictions:
        print(f"Predicted next cycle: {predictions['next_cycle_duration']:.1f} years")
        print(f"Predicted next rupture: ~{predictions['next_rupture_year']:.0f}")
    
    print(f"\nΩ trajectory: {[f'{o:.4f}' for o in predictions['omega_values']]}")
    print(f"Ω trend: {predictions['omega_trend']}")
    
    print(f"\nRupture magnitudes: {predictions['rupture_magnitudes']}")
    print(f"Next predicted magnitude: {predictions['next_rupture_magnitude']:.1f}/10")
    
    print(f"\nCurrent C/Ω ratio: {predictions['current_C_over_Omega']:.2f}")
    print(f"Memory selectivity: {predictions['memory_selectivity']}")
    
    # Print threats
    print("\n" + "=" * 70)
    print("CRR THREAT ANALYSIS")
    print("=" * 70)
    
    for threat in predictions['threat_analysis']:
        severity_bar = '█' * threat['severity'] + '░' * (10 - threat['severity'])
        print(f"\n  [{severity_bar}] {threat['severity']}/10  {threat['name']}")
        print(f"  Timeframe: {threat['timeframe']}")
        print(f"  CRR Mechanism: {threat['crr_mechanism']}")
    
    # Generate visualizations
    print("\n▸ Generating visualizations...")
    fig = create_visualizations(analysis)
    fig.savefig('/home/claude/crr_ai_analysis.png', dpi=200, 
                facecolor=fig.get_facecolor(), bbox_inches='tight')
    plt.close()
    print("  ✓ Saved crr_ai_analysis.png")
    
    # Export data for interactive visualization
    export_data = {
        'time': analysis.t.tolist(),
        'coherence': analysis.C.tolist(),
        'rupture_field': analysis.delta.tolist(),
        'regeneration': analysis.R.tolist(),
        'composite': analysis.composite.tolist(),
        'velocity': analysis.velocity.tolist(),
        'events': [(e[0], e[1], e[2], e[3], e[4]) for e in ai_events],
        'major_ruptures': analysis.major_ruptures,
        'omegas': analysis.omegas,
        'predictions': {
            'cycle_durations': predictions['cycle_durations'],
            'next_cycle_duration': predictions.get('next_cycle_duration', 3),
            'next_rupture_year': predictions.get('next_rupture_year', 2025),
            'omega_values': predictions['omega_values'],
            'rupture_magnitudes': predictions['rupture_magnitudes'],
            'next_rupture_magnitude': predictions['next_rupture_magnitude'],
        },
        'threats': predictions['threat_analysis']
    }
    
    with open('/home/claude/crr_data.json', 'w') as f:
        json.dump(export_data, f, indent=2, default=str)
    print("  ✓ Saved crr_data.json")
    
    print("\n" + "=" * 70)
    print("ANALYSIS COMPLETE")
    print("=" * 70)
    
    return analysis, predictions

if __name__ == '__main__':
    analysis, predictions = main()
